const express=require('express');
const cors=require('cors');
require('dotenv').config();

const app=express();

app.use(cors());
app.use(express.json());

app.post('/chat',async(req,res)=>{

const text=req.body.message;

res.json({
reply:'برعي بيقولك: '+text
});

});

app.listen(3000,()=>{
console.log('Server Running');
});
