self.addEventListener('install',()=>{
console.log('SW Ready');
});

self.addEventListener('push',event=>{
self.registration.showNotification('برعي',{
body:'عندك رسالة جديدة 🤖'
});
});
