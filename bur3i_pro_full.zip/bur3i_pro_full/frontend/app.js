const API_URL='https://YOUR-BACKEND.onrender.com/chat';

const chat=document.getElementById('chat');
const input=document.getElementById('message');

function addMessage(text,type){
const div=document.createElement('div');
div.className='msg '+type;
div.textContent=text;
chat.appendChild(div);
chat.scrollTop=chat.scrollHeight;
}

async function sendMessage(){

const text=input.value.trim();

if(!text)return;

addMessage(text,'user');

input.value='';

try{

const res=await fetch(API_URL,{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({message:text})
});

const data=await res.json();

addMessage(data.reply,'bot');

}catch(e){
addMessage('حصل مشكلة 😅','bot');
}
}

document.getElementById('sendBtn').onclick=sendMessage;

input.addEventListener('keydown',e=>{
if(e.key==='Enter')sendMessage();
});

if('serviceWorker' in navigator){
navigator.serviceWorker.register('./sw.js');
}

Notification.requestPermission();
